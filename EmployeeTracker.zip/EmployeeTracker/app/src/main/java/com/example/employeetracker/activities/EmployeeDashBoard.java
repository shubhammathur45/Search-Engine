package com.example.employeetracker.activities;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import com.example.employeetracker.R;

/**
 * Created by aayu on 1/2/2017.
 */
public class EmployeeDashBoard extends AppCompatActivity {


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_empdashboard);
    }
}
