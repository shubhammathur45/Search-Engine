package com.example.employeetracker.listeners;

/**
 * Created by aayu on 2/6/2017.
 */

public interface SubmitTaskListener {

     void submitTask(int id);
}
