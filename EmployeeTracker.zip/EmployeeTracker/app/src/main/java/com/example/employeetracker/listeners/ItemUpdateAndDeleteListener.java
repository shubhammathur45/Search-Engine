package com.example.employeetracker.listeners;

/**
 * Created by aayu on 1/12/2017.
 */
public interface ItemUpdateAndDeleteListener {

    public void deleteItem(int position);
    public void updateItem(int position);
}
